import "./App.css";
import Location from "./components/location/location";
//import Backpack from "./components/backpack/backpack";
import Grafic from "./components/grafic/grafic";
import Basketball from "./components/basketball/basketball";
import Microphone from "./components/microphone/microphone";
import FloorUp from "./components/floorUp/floorUp";
import FloorDown from "./components/floorDown/floorDown";
import RightBar from "./components/right-bar/right-bar";

/*
function App() {
  return (
    <>
      <Location />
      <Backpack />
      <Grafic />
      <Basketball />
      <Microphone />
      <FloorUp />
      <FloorDown />
    </>
  );
}
export default App;
*/
function App() {
  return (
    <>
      <RightBar />
    </>
  );
}
export default App;
