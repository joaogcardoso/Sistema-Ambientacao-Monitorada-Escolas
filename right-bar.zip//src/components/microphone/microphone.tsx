import "./microphone.css";
import { useState } from "react";

export default function microphone() {
  const [microphone, microphone2] = useState(false);

  const microphone3 = () => {
    microphone2(!microphone); // Alterna o estado
  };
  return (
    <>
      <div
        className={`microphone ${microphone ? "clicked" : ""}`} // Adiciona a classe 'clicked' se o estado for true
        onClick={microphone3}
      ></div>
    </>
  );
}
