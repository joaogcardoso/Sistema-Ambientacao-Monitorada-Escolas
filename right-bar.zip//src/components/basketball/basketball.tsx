import "./basketball.css";
import { useState } from "react";

export default function backetbal() {
  const [basketball, basketball2] = useState(false);

  const basketball3 = () => {
    basketball2(!basketball); // Alterna o estado
  };
  return (
    <>
      <div
        className={`basketball ${basketball ? "clicked" : ""}`} // Adiciona a classe 'clicked' se o estado for true
        onClick={basketball3}
      ></div>
    </>
  );
}
