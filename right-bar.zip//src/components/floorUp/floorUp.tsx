import "./floorUp.css";

export default function floorUp() {
  return (
    <>
      <div className="floorUp"></div>
      <div className="andar1"></div>
    </>
  );
}
