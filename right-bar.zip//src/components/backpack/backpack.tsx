/*import "./backpack.css";
import "./backpack2.svg";
import { useState } from "react";

export default function backpack() {
  const [backpack, backpack2] = useState(false);
  const [information, setInformation] = useState(false);

  const backpack3 = () => {
    backpack2(!backpack); // Alterna o estado
    if (information == false) {
      setInformation(true);
    } else {
      setInformation(false);
    }
  };

  function desativa() {
    const para = false;
  }

  return (
    <>
      <div
        className={`backpack ${backpack ? "clicked" : ""}`} // Adiciona a classe 'clicked' se o estado for true
        onClick={backpack3}
      ></div>
      {information && (
        <div className="winning-lineX" style={informationStyle()}>
          <h1 className="titulo"> Salas de Aula </h1>
          <div className="sala1">
            <h1 className="numeroSala1"> 01 </h1>
          </div>
          <div className="sala2">
            <h1 className="numeroSala2"> 02 </h1>
          </div>
          <div className="sala3">
            <h1 className="numeroSala3"> 03 </h1>
          </div>
          <div className="sala4">
            <h1 className="numeroSala4"> 04 </h1>
          </div>
          <div className="sala5">
            <h1 className="numeroSala5"> 05 </h1>
          </div>
          <div className="sala6">
            <h1 className="numeroSala6"> 06 </h1>
          </div>
        </div>
      )}
    </>
  );
}
function informationStyle() {
  return {
    top: `180px`,
    left: `1090px`,
    width: `600px`,
    height: `730px`,
    borderRadius: `50px`,
  };
}*/
