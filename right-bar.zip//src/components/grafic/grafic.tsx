import "./grafic.css";
import { useState } from "react";

export default function grafic() {
  const [grafic, grafic2] = useState(false);
  const [winningLineX, setWinningLineX] = useState(false);

  const grafic3 = () => {
    grafic2(!grafic); // Alterna o estado
    if (winningLineX == false) {
      setWinningLineX(true);
    } else {
      setWinningLineX(false);
    }
  };

  return (
    <>
      <div
        className={`grafic ${grafic ? "clicked" : ""}`} // Adiciona a classe 'clicked' se o estado for true
        onClick={grafic3}
      ></div>
      {winningLineX && (
        <div className="winning-lineX" style={calculateLineStyleX()}></div>
      )}
    </>
  );
}
function calculateLineStyleX() {
  return {
    top: `90px`,
    left: `200px`,
    width: `600px`,
    height: `500px`,
    borderRadius: `100px`,
  };
}
