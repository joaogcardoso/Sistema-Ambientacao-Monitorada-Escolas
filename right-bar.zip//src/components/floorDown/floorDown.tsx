import "./floorDown.css";

export default function floorDown() {
  return (
    <>
      <div className="floorDown"></div>
      <div className="andar2"></div>
    </>
  );
}
