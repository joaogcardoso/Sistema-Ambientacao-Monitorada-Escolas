import "./location.css";
import { useState } from "react";

export default function location() {
  const [location, location2] = useState(false);

  const location3 = () => {
    location2(!location); // Alterna o estado
  };
  return (
    <>
      <div
        className={`location ${location ? "clicked" : ""}`} // Adiciona a classe 'clicked' se o estado for true
        onClick={location3}
      ></div>
    </>
  );
}
